console.log("[executor] loaded");

/* ----------------------------- small utilities ---------------------------- */

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function jitter(min, max) {
  return Math.floor(min + Math.random() * (max - min));
}

function isNonEmptyString(x) {
  return typeof x === "string" && x.trim().length > 0;
}

function isProbablyCssSelector(str) {
  if (!isNonEmptyString(str)) return false;
  // approximate common selectors: starts with ., #, [, *, >, +, ~, : and contains non-space tokens
  return /^[.#\[>+~:*]/.test(str) || /\s/.test(str);
}

function looksLikeUrl(x) {
  return isNonEmptyString(x) && /^https?:\/\//i.test(x.trim());
}

function safeUrl(url) {
  try {
    const u = new URL(url, window.location.href);
    // block dangerous schemes
    if (!["http:", "https:"].includes(u.protocol)) return null;
    return u.toString();
  } catch {
    return null;
  }
}

function isGoogleSearchUrl(url) {
  try {
    const u = new URL(url);
    const isGoogle =
      u.hostname === "www.google.com" ||
      u.hostname.endsWith(".google.com") ||
      u.hostname === "google.com";
    return isGoogle && u.pathname === "/search" && u.searchParams.has("q");
  } catch {
    return false;
  }
}

function decodeGoogleQuery(url) {
  try {
    const u = new URL(url);
    return (u.searchParams.get("q") || "").trim();
  } catch {
    return "";
  }
}

// Extract JSON object/array out of a model string that might include extra text.
// Returns parsed object or null.
function extractAndParseJson(raw) {
  if (raw == null) return null;
  if (typeof raw === "object") return raw; // already parsed
  if (typeof raw !== "string") return null;

  const s = raw.trim();
  if (!s) return null;

  // Fast path: strict parse
  try {
    return JSON.parse(s);
  } catch {
    // continue
  }

  // Try to extract first {...} or [...] block.
  const firstObj = s.indexOf("{");
  const lastObj = s.lastIndexOf("}");
  const firstArr = s.indexOf("[");
  const lastArr = s.lastIndexOf("]");

  let candidate = null;

  if (firstObj !== -1 && lastObj !== -1 && lastObj > firstObj) {
    candidate = s.slice(firstObj, lastObj + 1);
  } else if (firstArr !== -1 && lastArr !== -1 && lastArr > firstArr) {
    candidate = s.slice(firstArr, lastArr + 1);
  }

  if (!candidate) return null;

  // One more parse attempt on extracted substring
  try {
    return JSON.parse(candidate);
  } catch {
    return null;
  }
}

/* ----------------------------- target handling ---------------------------- */

// Allow target to be either:
// - string (legacy): passed to your findElement(string)
// - object locator: { css, text, href, role, name } (we'll resolve a few common forms)
function resolveTarget(target) {
  if (isNonEmptyString(target)) {
    const raw = target.trim();

    // If target looks like a URL, prefer matching anchor href
    if (looksLikeUrl(raw)) {
      const href = safeUrl(raw);
      if (href) {
        const anchor = document.querySelector(`a[href="${CSS.escape(href)}"]`);
        if (anchor && isElementClickable(anchor)) return anchor;
      }
    }

    // String may be CSS selector, exact link text, or contains link text.
    if (isProbablyCssSelector(raw)) {
      try {
        const sel = document.querySelector(raw);
        if (sel && isElementClickable(sel)) return sel;
      } catch {
        // invalid selector
      }
    }

    // Fallback to text-based resolution via legacy findElement behavior.
    const found = findElement({ text: raw });
    if (found) return found;

    return findElement(raw);
  }

  if (isNonEmptyString(target.css)) {
    try {
      const el = document.querySelector(target.css.trim());
      if (el) return el;
    } catch {
      // invalid selector
    }
  }

  // href locator (exact or contains)
  if (isNonEmptyString(target.href)) {
    const href = target.href.trim();
    // exact match first
    let el = document.querySelector(`a[href="${CSS.escape(href)}"]`);
    if (el) return el;

    // contains match fallback
    const anchors = Array.from(document.querySelectorAll("a[href]"));
    el = anchors.find((a) => a.getAttribute("href")?.includes(href));
    if (el) return el;
  }

  // text locator (visible elements only; conservative)
  if (isNonEmptyString(target.text)) {
    const needle = target.text.trim().toLowerCase();
    const candidates = Array.from(
      document.querySelectorAll("a,button,[role='button'],[role='link']"),
    )
      .filter(isElementClickable)
      .filter((el) => {
        const t = (el.innerText || el.textContent || "").trim().toLowerCase();
        return t && (t === needle || t.includes(needle));
      });

    return pickBestVisible(candidates);
  }

  // role+name locator (basic)
  if (isNonEmptyString(target.role) && isNonEmptyString(target.name)) {
    const role = target.role.trim().toLowerCase();
    const name = target.name.trim().toLowerCase();
    const sel =
      role === "button"
        ? "button,[role='button']"
        : role === "link"
          ? "a,[role='link']"
          : null;

    if (sel) {
      const candidates = Array.from(document.querySelectorAll(sel))
        .filter(isElementClickable)
        .filter((el) => {
          const t = (el.innerText || el.textContent || "").trim().toLowerCase();
          const aria = (el.getAttribute("aria-label") || "")
            .trim()
            .toLowerCase();
          return (
            (t && (t === name || t.includes(name))) ||
            (aria && (aria === name || aria.includes(name)))
          );
        });

      return pickBestVisible(candidates);
    }
  }

  return null;
}

function isElementVisible(el) {
  if (!el) return false;
  const rect = el.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) return false;
  // must intersect viewport a bit
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const intersects =
    rect.bottom >= 0 && rect.right >= 0 && rect.top <= vh && rect.left <= vw;
  if (!intersects) return false;

  const style = window.getComputedStyle(el);
  if (
    style.visibility === "hidden" ||
    style.display === "none" ||
    Number(style.opacity) === 0
  )
    return false;
  return true;
}

function isElementClickable(el) {
  if (!el) return false;
  if (!isElementVisible(el)) return false;
  // avoid disabled buttons
  if ("disabled" in el && el.disabled) return false;
  return true;
}

function pickBestVisible(elements) {
  const els = (elements || []).filter(isElementClickable);
  if (!els.length) return null;

  // pick the most "central" visible element (simple heuristic)
  const cx = window.innerWidth / 2;
  const cy = window.innerHeight / 2;

  let best = els[0];
  let bestScore = Infinity;

  for (const el of els) {
    const r = el.getBoundingClientRect();
    const ex = r.left + r.width / 2;
    const ey = r.top + r.height / 2;
    const dist = Math.hypot(ex - cx, ey - cy);
    if (dist < bestScore) {
      bestScore = dist;
      best = el;
    }
  }
  return best;
}

/* ----------------------------- legacy findElement ---------------------------- */

function findElement(target = {}) {
  if (isNonEmptyString(target)) {
    const raw = target.trim();

    // If looks like CSS selector, try it first
    if (isProbablyCssSelector(raw)) {
      try {
        const el = document.querySelector(raw);
        if (el) return el;
      } catch {
        // invalid selector
      }
    }

    // URL target -> matching anchor by href
    if (looksLikeUrl(raw)) {
      const href = safeUrl(raw);
      if (href) {
        const a = document.querySelector(`a[href="${CSS.escape(href)}"]`);
        if (a) return a;
      }
    }

    // Treat as text content for link/button locators
    target = { text: raw };
  }

  const { selector, text, hrefIncludes } = target;

  if (selector) {
    const el = document.querySelector(selector);
    if (el) return el;
  }

  if (text) {
    const normalized = text.trim().toLowerCase();
    const candidates = Array.from(
      document.querySelectorAll(
        "a, button, [role='button'], input[type='submit'], input[type='button']",
      ),
    );

    const exact =
      candidates.find(
        (e) =>
          (e.innerText || e.value || "").trim().toLowerCase() === normalized,
      ) ||
      candidates.find((e) =>
        (e.innerText || e.value || "")
          .trim()
          .toLowerCase()
          .includes(normalized),
      );

    if (exact) return exact;
  }

  if (hrefIncludes) {
    const needle = hrefIncludes.toLowerCase();
    const candidates = Array.from(document.querySelectorAll("a[href]"));
    const el = candidates.find((a) =>
      (a.href || "").toLowerCase().includes(needle),
    );
    if (el) return el;
  }

  return null;
}

/* ------------------------- skills: search / read -------------------------- */

async function executeSearch(query, opts = {}) {
  const q = String(query || "").trim();
  if (!q) return;

  const engine = (opts.engine || "google").toLowerCase();

  // If we're on Google home, use the search box; else just navigate to results.
  const onGoogleHome =
    location.hostname.endsWith("google.com") &&
    (location.pathname === "/" || location.pathname === "/webhp");

  if (engine === "google" && onGoogleHome) {
    const input =
      document.querySelector('textarea[name="q"]') ||
      document.querySelector('input[name="q"]') ||
      document.querySelector('input[type="text"][name="q"]');

    if (input) {
      input.focus();
      input.value = q;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));

      // After input.value = q; and input/change events...
      const ok = submitSearch(input);
      if (!ok) {
        // last resort: navigate directly to results
        location.href = `https://www.google.com/search?q=${encodeURIComponent(q)}`;
      }
      return;
    }
  }

  // Submit reliably: try Enter (keydown/keypress/keyup), then form.submit(), then click search button
  function submitSearch(input) {
    const fireKey = (type) =>
      input.dispatchEvent(
        new KeyboardEvent(type, {
          key: "Enter",
          code: "Enter",
          keyCode: 13,
          which: 13,
          bubbles: true,
          cancelable: true,
        }),
      );

    // 1) Try the full key sequence (some listeners are on keypress)
    fireKey("keydown");
    fireKey("keypress");
    fireKey("keyup");

    // 2) Try submitting the surrounding form
    const form = input.closest("form");
    if (form) {
      // requestSubmit is best if available (triggers submit handlers)
      if (typeof form.requestSubmit === "function") {
        form.requestSubmit();
        return true;
      }
      // fallback: dispatch submit event then submit()
      const ev = new Event("submit", { bubbles: true, cancelable: true });
      if (form.dispatchEvent(ev)) {
        try {
          form.submit();
          return true;
        } catch {}
      }
    }

    // 3) Try clicking Google's search button
    const btn =
      document.querySelector('button[type="submit"]') ||
      document.querySelector('input[type="submit"]') ||
      document.querySelector('button[aria-label="Google Search"]') ||
      document.querySelector('input[aria-label="Google Search"]');

    if (btn) {
      btn.click();
      return true;
    }

    return false;
  }

  // Fallback: navigate
  const url =
    engine === "duckduckgo"
      ? `https://duckduckgo.com/?q=${encodeURIComponent(q)}`
      : `https://www.google.com/search?q=${encodeURIComponent(q)}`;

  window.location.href = url;
}

function hasDecisionRichZones() {
  const decisionTexts = [
    "related articles",
    "next",
    "see also",
    "recommended",
    "more stories",
    "trending",
    "navigation",
    "menu",
    "links",
    "explore",
  ];

  const decisionSelectors = [
    "nav",
    "aside",
    ".sidebar",
    ".related",
    ".recommendations",
    ".nav",
    ".menu",
    "[role='navigation']",
  ];

  // Check text in links/buttons
  const elements = document.querySelectorAll(
    "a, button, [role='button'], h2, h3, .heading",
  );
  for (const el of elements) {
    const text = (el.innerText || el.textContent || "").toLowerCase().trim();
    if (decisionTexts.some((t) => text.includes(t))) {
      return true;
    }
  }

  // Check selectors
  for (const sel of decisionSelectors) {
    if (document.querySelector(sel)) {
      return true;
    }
  }

  return false;
}

async function executeRead(params = {}) {
  // params: { seconds?: number, mode?: "scan"|"deep" }
  const seconds = Number(params.seconds);
  const mode = (params.mode || "scan").toLowerCase();

  const totalMs = Number.isFinite(seconds)
    ? Math.max(1, Math.min(60, seconds)) * 1000
    : mode === "deep"
      ? 12000
      : 6000;

  const start = Date.now();

  await sleep(jitter(400, 900));

  while (Date.now() - start < totalMs) {
    window.scrollBy({ top: window.innerHeight, behavior: "smooth" });
    await sleep(jitter(1000, 2000));

    if (hasDecisionRichZones()) {
      break;
    } else {
      await sleep(jitter(800, 1500));
    }
  }
}

/* ---------------------- skill: open_result (SERP) ------------------------- */

function isLikelySerpPage() {
  const host = location.hostname;
  if (host.includes("google.") && location.pathname === "/search") return true;
  if (host.includes("duckduckgo.") && location.pathname === "/") {
    // DDG results often still at /
    return new URLSearchParams(location.search).has("q");
  }
  return false;
}

function getSerpResultLinks() {
  const host = location.hostname;

  // Google: anchors inside main results region (#search) are usually organic.
  if (host.includes("google.") && location.pathname === "/search") {
    const region = document.querySelector("#search") || document.body;
    const anchors = Array.from(region.querySelectorAll("a[href]"));

    return anchors
      .filter((a) => isElementClickable(a))
      .map((a) => ({ a, href: a.getAttribute("href") || "" }))
      .filter(({ href }) => href && !href.startsWith("#"))
      .filter(({ href }) => {
        // avoid google internal nav / caches / accounts / settings / etc.
        if (href.startsWith("/")) return false;
        if (href.includes("google.com/")) return false;
        return true;
      })
      .filter(({ a }) => {
        const t = (a.innerText || "").trim();
        return t.length >= 8; // avoid tiny junk
      })
      .map(({ a }) => a);
  }

  // DuckDuckGo: results links tend to be a.result__a
  if (host.includes("duckduckgo.")) {
    const anchors = Array.from(document.querySelectorAll("a.result__a[href]"));
    return anchors.filter(isElementClickable);
  }

  // Generic fallback: pick visible links in main-ish content
  const main = document.querySelector("main") || document.body;
  return Array.from(main.querySelectorAll("a[href]")).filter(
    isElementClickable,
  );
}

async function executeOpenResult(params = {}) {
  // params: { rank?: number, openInNewTab?: boolean, mustInclude?: string[] }
  console.log("[executor] open_result with params:", params);

  const rank = Number(params.rank);
  const openInNewTab = !!params.openInNewTab;
  const mustInclude = Array.isArray(params.mustInclude)
    ? params.mustInclude.map((s) => String(s).toLowerCase()).filter(Boolean)
    : [];

  if (!isLikelySerpPage()) {
    console.warn(
      "[executor] open_result: not on a recognized results/list page",
    );
    return;
  }

  if (params.links && Array.isArray(params.links)) {
    let hrefs = params.links
      .map((link) => {
        const parts = link.split(" — ");
        return parts.length > 1 ? parts[parts.length - 1] : link;
      })
      .filter((href) => href && safeUrl(href));

    if (mustInclude.length) {
      hrefs = hrefs.filter((href) => {
        const txt = href.toLowerCase();
        return mustInclude.every((w) => txt.includes(w));
      });
    }

    if (!hrefs.length) {
      console.log("[executor] links.length:" + hrefs.length);
      console.warn("[executor] open_result: no suitable links found");
      return;
    }

    const idx = Number.isFinite(rank)
      ? Math.max(0, Math.min(hrefs.length - 1, rank - 1))
      : 0;
    const chosenHref = hrefs[idx];

    console.log("[executor] open_result: chosen", { rank, chosenHref });

    if (openInNewTab) {
      // Try background OPEN_TAB
      try {
        if (typeof browser !== "undefined" && browser?.runtime?.sendMessage) {
          await browser.runtime.sendMessage({
            type: "OPEN_TAB",
            url: chosenHref,
            active: true,
          });
          console.log("[executor] open_result: opened via background OPEN_TAB");
          return;
        }
      } catch (e) {
        console.warn("[executor] open_result: background OPEN_TAB failed", e);
      }

      // window.open
      const w = window.open(chosenHref, "_blank", "noopener,noreferrer");
      if (w) {
        console.log("[executor] open_result: opened via window.open");
        return;
      }

      // Last resort: same tab
      console.warn(
        "[executor] open_result: window.open blocked; navigating same tab",
      );
      window.location.assign(chosenHref);
    } else {
      console.log("[executor] open_result: navigating via location.assign");
      window.location.assign(chosenHref);
    }
    return;
  }

  let links = getSerpResultLinks();

  if (mustInclude.length) {
    links = links.filter((a) => {
      const txt = (
        (a.innerText || a.textContent || "") +
        " " +
        (a.href || "")
      ).toLowerCase();
      return mustInclude.every((w) => txt.includes(w));
    });
  }

  links = links.filter((a) => !!safeUrl(a.href));

  // Deduplicate by normalized href
  const seen = new Set();
  const deduped = [];
  for (const a of links) {
    const href = safeUrl(a.href);
    if (!href) continue;
    if (seen.has(href)) continue;
    seen.add(href);
    deduped.push(a);
  }
  links = deduped;

  if (!links.length) {
    console.log("[executor] links.length:" + links.length);
    console.warn("[executor] open_result: no suitable links found");
    return;
  }

  const idx = Number.isFinite(rank)
    ? Math.max(1, Math.min(links.length, rank)) - 1
    : 0;

  const chosen = links[idx];
  const href = safeUrl(chosen.href);

  console.log("[executor] open_result: chosen", {
    idx,
    href,
    text: (chosen.innerText || chosen.textContent || "").trim(),
  });

  chosen.scrollIntoView({ block: "center", behavior: "smooth" });
  await sleep(jitter(250, 600));

  // ----- helpers -----
  const fireMouseSequence = (el) => {
    const opts = { bubbles: true, cancelable: true, view: window };
    // Some SERPs listen on pointer/mouse down rather than click.
    el.dispatchEvent(new PointerEvent("pointerdown", opts));
    el.dispatchEvent(new MouseEvent("mousedown", opts));
    el.dispatchEvent(new MouseEvent("mouseup", opts));
    el.dispatchEvent(new MouseEvent("click", opts));
  };

  const tryClick = async (el) => {
    try {
      // Try normal click first (simple)
      el.click();
      await sleep(jitter(60, 140));
      return true;
    } catch (e) {
      console.warn("[executor] open_result: el.click() threw", e);
      return false;
    }
  };

  const tryMouseSequence = async (el) => {
    try {
      fireMouseSequence(el);
      await sleep(jitter(60, 140));
      return true;
    } catch (e) {
      console.warn("[executor] open_result: mouse sequence threw", e);
      return false;
    }
  };

  const openViaBackgroundIfPossible = async (url) => {
    // If you're in a Firefox extension content script, this is the most reliable way
    // to open a new tab without popup blocking.
    try {
      if (typeof browser !== "undefined" && browser?.runtime?.sendMessage) {
        await browser.runtime.sendMessage({
          type: "OPEN_TAB",
          url,
          active: true,
        });
        return true;
      }
    } catch (e) {
      // ignore; fallback below
      console.warn("[executor] open_result: background OPEN_TAB failed", e);
    }
    return false;
  };

  // ----- action -----
  if (openInNewTab) {
    if (!href) {
      console.warn(
        "[executor] open_result: no href to open in new tab, clicking instead",
      );
      await tryMouseSequence(chosen);
      await tryClick(chosen);
      return;
    }

    // Best: ask background to open tab (avoids popup blocking)
    const opened = await openViaBackgroundIfPossible(href);
    if (opened) {
      console.log("[executor] open_result: opened via background OPEN_TAB");
      return;
    }

    // Next: window.open (may be blocked)
    const w = window.open(href, "_blank", "noopener,noreferrer");
    if (w) {
      console.log("[executor] open_result: opened via window.open");
      return;
    }

    // Last resort: navigate same tab
    console.warn(
      "[executor] open_result: window.open blocked; navigating same tab",
    );
    window.location.assign(href);
    return;
  }

  // Same tab: clicking is unreliable on SERPs; navigate directly when possible.
  if (href) {
    console.log("[executor] open_result: navigating via location.assign");
    window.location.assign(href);
    return;
  }

  // If no href (edge case), attempt click strategies
  await tryMouseSequence(chosen);
  await tryClick(chosen);
}

/* --------------------- decision validation + normalization ---------------- */

const ALLOWED_ACTIONS = new Set([
  "click",
  "type",
  "scroll",
  "navigate",
  "search",
  "open_result",
  "read",
  "back",
  "wait",
  "noop",
]);

function normalizeDecision(rawDecision) {
  const parsed = extractAndParseJson(rawDecision);
  if (!parsed || typeof parsed !== "object") return null;

  // Support array-of-decisions: take first valid
  if (Array.isArray(parsed)) {
    for (const item of parsed) {
      const n = normalizeDecision(item);
      if (n) return n;
    }
    return null;
  }

  const d = { ...parsed };

  // Normalize action casing / aliases
  if (typeof d.action === "string") d.action = d.action.trim().toLowerCase();
  if (d.action === "none") d.action = "noop";
  if (d.action === "no-op") d.action = "noop";

  // Some models use target/value inconsistently; try mild repair
  // navigate: accept url in target or url
  if (d.action === "navigate") {
    if (!isNonEmptyString(d.value)) {
      if (isNonEmptyString(d.url)) d.value = d.url;
      else if (isNonEmptyString(d.target)) d.value = d.target;
    }
  }

  // click: if target is a URL, interpret as navigate/search intent
  if (d.action === "click" && looksLikeUrl(d.target)) {
    const url = d.target.trim();
    if (isGoogleSearchUrl(url)) {
      const q = decodeGoogleQuery(url);
      if (q) return { action: "search", value: q, engine: "google" };
    }
    return { action: "navigate", value: url };
  }

  // search: allow query in value/target/query
  if (d.action === "search") {
    if (!isNonEmptyString(d.value)) {
      if (isNonEmptyString(d.query)) d.value = d.query;
      else if (isNonEmptyString(d.target)) d.value = d.target;
    }
    if (!isNonEmptyString(d.engine)) d.engine = "google";
  }

  // read: allow seconds in value
  if (d.action === "read") {
    if (d.seconds == null && d.value != null) d.seconds = d.value;
    if (!isNonEmptyString(d.mode)) d.mode = "scan";
  }

  // open_result: allow rank in value
  if (d.action === "open_result") {
    if (d.rank == null && d.value != null) d.rank = d.value;
  }

  // scroll: normalize numbers to strings
  if (d.action === "scroll") {
    if (typeof d.value === "number") d.value = String(d.value);
    if (isNonEmptyString(d.value)) d.value = d.value.trim().toLowerCase();
  }

  // wait: normalize ms
  if (d.action === "wait") {
    if (typeof d.value === "string") d.value = d.value.trim();
    if (typeof d.value === "number") d.value = Math.floor(d.value);
  }

  return d;
}

function validateDecision(d) {
  const errors = [];

  if (!d || typeof d !== "object") {
    errors.push("decision_not_object");
    return { ok: false, errors };
  }

  if (!isNonEmptyString(d.action)) {
    errors.push("missing_action");
    return { ok: false, errors };
  }

  if (!ALLOWED_ACTIONS.has(d.action)) {
    errors.push(`unknown_action:${d.action}`);
    return { ok: false, errors };
  }

  switch (d.action) {
    case "click":
      if (d.target == null) errors.push("click_missing_target");
      break;

    case "type":
      if (d.target == null) errors.push("type_missing_target");
      if (!isNonEmptyString(d.value)) errors.push("type_missing_value");
      break;

    case "scroll": {
      const v = d.value;
      if (!isNonEmptyString(v)) errors.push("scroll_missing_value");
      else if (v !== "up" && v !== "down" && Number.isNaN(Number(v)))
        errors.push("scroll_bad_value");
      break;
    }

    case "navigate": {
      const url = safeUrl(d.value);
      if (!url) errors.push("navigate_bad_url");
      else d.value = url; // canonicalize
      break;
    }

    case "search":
      if (!isNonEmptyString(d.value)) errors.push("search_missing_query");
      break;

    case "open_result":
      // rank optional; defaults to 1
      if (d.rank != null && Number.isNaN(Number(d.rank)))
        errors.push("open_result_bad_rank");
      break;

    case "read":
      if (d.seconds != null && Number.isNaN(Number(d.seconds)))
        errors.push("read_bad_seconds");
      break;

    case "wait":
      // optional; if missing we'll jitter
      if (d.value != null) {
        const ms = typeof d.value === "number" ? d.value : Number(d.value);
        if (!Number.isFinite(ms)) errors.push("wait_bad_ms");
      }
      break;

    case "back":
    case "noop":
      break;

    default:
      break;
  }

  return { ok: errors.length === 0, errors };
}

/* ----------------------------- core executor ------------------------------ */

async function executeDecision(rawDecision, links) {
  console.log("[executor] raw decision:", rawDecision);
  const d = normalizeDecision(rawDecision);
  if (!d) return;

  const { ok, errors } = validateDecision(d);
  if (!ok) {
    console.warn("[executor] invalid decision:", d, "errors:", errors);
    return;
  }

  switch (d.action) {
    /* -------- skills -------- */

    case "search": {
      // Basic "sanity" guard: avoid empty / absurdly long queries
      const q = String(d.value).trim();
      if (q.length > 180) {
        console.warn("[executor] search query too long; refusing:", q);
        return;
      }
      await executeSearch(q, { engine: d.engine });
      return;
    }

    case "open_result": {
      console.log("[executor] executing open_result with params:", d);
      await executeOpenResult({
        rank: d.rank != null ? Number(d.rank) : 1,
        openInNewTab: !!d.openInNewTab,
        mustInclude: d.mustInclude,
        links: links,
      });
      return;
    }

    case "read": {
      await executeRead({ seconds: d.seconds, mode: d.mode });
      return;
    }

    /* -------- primitives -------- */

    case "click": {
      // Preflight: resolve element (supports string or locator object)
      const el = resolveTarget(d.target);
      if (!el) {
        // One more repair attempt: if target is url-like string and anchor exists, click it
        if (looksLikeUrl(d.target)) {
          const href = safeUrl(d.target);
          if (href) {
            const a = document.querySelector(`a[href="${CSS.escape(href)}"]`);
            if (a) {
              a.scrollIntoView({ block: "center", behavior: "smooth" });
              await sleep(jitter(150, 450));
              a.click();
              return;
            }
          }
        }

        return console.warn("[executor] click target not found:", d.target);
      }

      el.scrollIntoView({ block: "center", behavior: "smooth" });
      await sleep(jitter(150, 450));
      el.click();
      return;
    }

    case "type": {
      const el = resolveTarget(d.target);
      if (!el)
        return console.warn("[executor] type target not found:", d.target);

      const value = String(d.value);

      el.scrollIntoView?.({ block: "center", behavior: "smooth" });
      await sleep(jitter(120, 350));

      el.focus?.();

      if ("value" in el) {
        el.value = value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else if (el.isContentEditable) {
        el.textContent = value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
      }

      // Optional: press Enter if requested (common for search boxes)
      if (d.pressEnter) {
        el.dispatchEvent(
          new KeyboardEvent("keydown", {
            key: "Enter",
            code: "Enter",
            bubbles: true,
          }),
        );
        el.dispatchEvent(
          new KeyboardEvent("keyup", {
            key: "Enter",
            code: "Enter",
            bubbles: true,
          }),
        );
      }

      return;
    }

    case "scroll": {
      const v = String(d.value).trim().toLowerCase();
      if (v === "down") {
        window.scrollBy({
          top: window.innerHeight * 0.9,
          behavior: "smooth",
        });
      } else if (v === "up") {
        window.scrollBy({
          top: -window.innerHeight * 0.9,
          behavior: "smooth",
        });
      } else {
        const px = Number(v);
        if (!Number.isNaN(px)) {
          const clamped = Math.max(-5000, Math.min(5000, px));
          window.scrollBy({ top: clamped, behavior: "smooth" });
        }
      }
      return;
    }

    case "navigate": {
      const url = safeUrl(d.value);
      if (!url) return console.warn("[executor] navigate bad url:", d.value);
      window.location.href = url;
      return;
    }

    case "back": {
      console.log("[executor] navigating back");
      window.history.back();
      return;
    }

    case "wait": {
      let ms = null;
      if (typeof d.value === "number") ms = d.value;
      else if (typeof d.value === "string") ms = Number(d.value);

      const delay = Number.isFinite(ms)
        ? Math.max(50, Math.min(15000, ms))
        : jitter(350, 1200);

      await sleep(delay);
      return;
    }

    case "noop":
    default:
      return;
  }
}

window.PuppeteerExecutor = {
  findElement,
  resolveTarget,
  isElementVisible,
  isElementClickable,
  pickBestVisible,
  executeSearch,
  executeRead,
  executeOpenResult,
  normalizeDecision,
  validateDecision,
  executeDecision,
};
